seims.scenario_analysis package {#intro_scenario_analysis_pkg}
==============================================================

TODO.

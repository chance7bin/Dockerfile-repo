seims.preprocess.autofuzslppos package {#intro_autofuzslppos_pkg}
=================================================================

Python scripts of [AutoFuzSlpPos](https://github.com/lreis2415/AutoFuzSlpPos)

## Changelogs
+ 2019-01-23: First integrated AutoFuzSlpPos (v2019.1.23, commit [838497afcfbd2152e4ab88f4025408b99c20de1c](https://github.com/lreis2415/AutoFuzSlpPos/commit/838497afcfbd2152e4ab88f4025408b99c20de1c)) into SEIMS.

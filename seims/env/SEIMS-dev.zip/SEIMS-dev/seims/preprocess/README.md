seims.preprocess package {#intro_preprocess_pkg}
================================================

TODO.

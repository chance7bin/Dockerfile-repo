﻿package inferEngine;

import java.util.HashMap;

public class AlgorithmScenario {

	public HashMap<String,String> condition_value = new HashMap<String,String>();
}

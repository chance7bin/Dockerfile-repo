The contributions for the knowledge base from the community through GitHub issues are welcomed. 

1.2 Why SEIMS? {#why_seims}
==================================

[TOC]

Coming soon...

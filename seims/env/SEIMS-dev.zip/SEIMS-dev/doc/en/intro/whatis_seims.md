1.1 What is SEIMS? {#whatis_seims}
==================================

[TOC]

Coming soon...

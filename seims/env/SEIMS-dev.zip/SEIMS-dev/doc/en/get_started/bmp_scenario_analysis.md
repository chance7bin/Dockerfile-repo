2.8 BMP scenario analysis {#bmp_scenario_analysis}
======================================================

[TOC]

Coming soon...

Also see introduction of the Python package @subpage intro_scenario_analysis_pkg
and @subpage intro_scenario_analysis_spatialunits_pkg

5.3 Ecology {#ecology_theory}
=============================

[TOC]

Coming soon...

metis
=====

METIS - Serial Graph Partitioning and Fill-reducing Matrix Ordering

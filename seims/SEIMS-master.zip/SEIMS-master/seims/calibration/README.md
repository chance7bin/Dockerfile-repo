seims.calibration package {#intro_auto_calibration_pkg}
================================================================


## Developing plan
- [x] NSGA-II Algorithm (Deb et al., 2002).
- [ ] SCE-UA (Duan, 1992).

Code references:
[Optimization_SCE](https://github.com/stijnvanhoey/Optimization_SCE),
[PSUADE](https://computation.llnl.gov/projects/psuade/software).

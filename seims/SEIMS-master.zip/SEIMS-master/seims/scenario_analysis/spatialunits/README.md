seims.scenario_analysis.spatialunits package {#intro_scenario_analysis_spatialunits_pkg}
===========================================================================

TODO.


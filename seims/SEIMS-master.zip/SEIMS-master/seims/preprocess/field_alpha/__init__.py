"""@package field_alpha
Preprocessing for field version of SEIMS.

Need to be integrated to seims.preprocess package!
"""
from __future__ import absolute_import

__author__ = "SEIMS Team"

Predefined database {#intro_predefined_database}
================================================

The predefined database includes serval lookup tables, initial model parameters, and available output settings.

+ These filename should not be changed!
+ Lookup table can be appended or prepared separated in other place.

--------------------------------------------

SEIMS模型预定义数据库包括土地利用、土壤属性查找表，模型初始参数以及所有可供输出的变量设置。

+ 这些文件名不允许修改！
+ 查找表可根据需要追加内容，或者在模型数据准备中提供。

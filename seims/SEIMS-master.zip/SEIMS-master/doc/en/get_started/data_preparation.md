2.2 Data preparation of demo watershed {#data_preparation}
==========================================================

[TOC]

Coming soon...

Predefined database @subpage intro_predefined_database

Also see introduction of the Python packages @subpage intro_preprocess_pkg and @subpage intro_autofuzslppos_pkg

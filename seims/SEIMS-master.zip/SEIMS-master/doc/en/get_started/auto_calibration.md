2.7 Auto-Calibration {#auto_calibration}
======================================================

[TOC]

Coming soon...

Also see introduction of the Python package @subpage intro_auto_calibration_pkg

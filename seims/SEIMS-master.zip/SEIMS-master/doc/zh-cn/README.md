About {#mainpage}
=====================

Copyright (C) 2018 [Lreis](http://www.lreis.ac.cn), [IGSNRR](http://www.igsnrr.cas.cn), [CAS](http://www.cas.cn), and [NJNU](http://www.njnu.edu.cn). All rights reserved.

* [SEIMS GitHub](https://github.com/lreis2415/SEIMS)
* SEIMS Documentations (**Not finished yet!**)
  * Online versions
    * [English (powered by Doxygen)](https://lreis2415.github.io/SEIMS/)
    * [简体中文（由Doxygen驱动）](https://lreis2415.github.io/SEIMS/zh-cn/)

# 简介


# 联系我们
+ 朱良君 (zlj@lreis.ac.cn)
+ 刘军志 (liujunzhi@njnu.edu.cn)


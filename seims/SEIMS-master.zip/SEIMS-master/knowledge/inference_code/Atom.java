package inferEngine;

public class Atom {

	public String var;
	public String rel;
	public String ind;
}

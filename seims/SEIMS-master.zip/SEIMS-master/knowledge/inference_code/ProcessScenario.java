package inferEngine;

import java.util.HashMap;


public class ProcessScenario {

	public HashMap<String,String> condition_value = new HashMap<String,String>();
	
}
